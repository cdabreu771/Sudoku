package Sudoku;

// This class handles the game board. It includes main.
public class GameManager {
	
	// This is the main for the Sudoku game.
	public static void main(String[] args) {	
		LogInScreen newGame = new LogInScreen();
		
	}
}

