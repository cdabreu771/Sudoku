Name: Camille d'Abreu
JDK Used:JDK Used: Oracle 12
IDE Used: Eclipse version 2019-03 (4.11.0)
Main File: GameBoardManager
Load File: the move file is named contents.txt and the location variable must be changed to reflect the location 
within the running computer. Currently, it is hardcoded to //Users//Camille//Documents//COEN275//Assignment1//src/Sudoku//contents.txt
Other Instructions: contents.txt contains the sudoku puzzle that the program will be using. solution.txt contains 
the solution to the given puzzle. It is not used by the program.