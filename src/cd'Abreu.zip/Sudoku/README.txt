Name: Camille d'Abreu
JDK Used:JDK Used: Oracle 12
IDE Used: Eclipse version 2019-03 (4.11.0)
Main File: GameManager
Load File: the move file is named contents.txt and the location variable must be changed to reflect the location 
within the running computer. Currently, it is hardcoded to //Users//Camille//Documents//COEN275//Assignment1//src/Sudoku//contents.txt
within the SudokuJPanel class.
The image file is name sudoku.png and the location variable must be changed to reflect the location within the running 
computer. Currently, it is hardcoded to //Users//Camille//Documents//COEN275//Assignment1//src//Sudoku//sudoku.png
within the LogInScreen class.
The game account file is name PlayerDB.txt and the location variable must be changed to reflect the location 
within the running computer. Currently, it is hardcoded to //Users//Camille//Documents//COEN275//Assignment1//src//Sudoku//PlayerDB.txt 
within the GameAccountManager class.
Other Instructions: contents.txt contains the sudoku puzzle that the program will be using. solution.txt contains 
the solution to the given puzzle. It is not used by the program.