package Sudoku;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;


// This class creates the UI for the GameBoard
public class GameBoard {
	private static final Color WHITE = Color.WHITE;
	private static final Color GREEN = Color.GREEN;
	private static final Color ORANGE = Color.ORANGE;
	GameAccount account = new GameAccount();
	Timer timer;
	String mseconds = "00";
	String seconds = "00";
	String minutes = "00";
	//int hour = 00;
	
	
	
	// This is the constructor for the GameBoard. It calls createGameBoard().
	protected GameBoard(GameAccount account) {
		this.account = account;
		createGameBoard();
	}
	
	// This function creates the game board.
	private void createGameBoard() {
		
		// Sudoku Game Screen
		JFrame frame = new JFrame("Sudoku");
		//JPanel homePanel = new JPanel();
		JPanel RPanel = new JPanel();
		JPanel LPanel = new JPanel();
		JPanel LPanelTop = new JPanel();
		JPanel LPanelCenter = new JPanel();
		JPanel LPanelBottom = new JPanel();
		SudokuJPanel sudokuPanel = new SudokuJPanel(account);
		
		Font font1 = new Font("Arial", Font.BOLD,26);
		JLabel label1 = new JLabel("Scoreboard");
		label1.setFont(font1);
		JLabel label2a = new JLabel("Player Name:");
		JLabel label2b = new JLabel(account.getPlayerName());
		JLabel label3a = new JLabel("Number of Games Played:");
		JLabel label3b = new JLabel(Integer.toString(account.getGamesPlayed()));
		JLabel label4a = new JLabel("Number of Games Won:");
		JLabel label4b = new JLabel(Integer.toString(account.getGamesWon()));
		JLabel label5a = new JLabel("Number of Games Lost:");
		JLabel label5b = new JLabel(Integer.toString(account.getGamesLost()));
		JLabel label6a = new JLabel("Total Score:");
		JLabel label6b = new JLabel(Integer.toString(account.getTotalScore()));
		
		
		label1.setPreferredSize(new Dimension(20,20));
		label2a.setPreferredSize(new Dimension(10,5));
		label2b.setPreferredSize(new Dimension(10,5));
		label3a.setPreferredSize(new Dimension(10,5));
		label3b.setPreferredSize(new Dimension(10,5));
		label4a.setPreferredSize(new Dimension(10,5));
		label4b.setPreferredSize(new Dimension(10,5));
		label5a.setPreferredSize(new Dimension(10,5));
		label5b.setPreferredSize(new Dimension(10,5));
		label6a.setPreferredSize(new Dimension(10,5));
		label6b.setPreferredSize(new Dimension(10,5));
		
		
		
		GridLayout layout1 = new GridLayout(5,2);
		LPanelTop.setLayout(layout1);
		LPanelTop.add(label2a);
		LPanelTop.add(label2b);
		LPanelTop.add(label3a);
		LPanelTop.add(label3b);
		LPanelTop.add(label4a);
		LPanelTop.add(label4b);
		LPanelTop.add(label5a);
		LPanelTop.add(label5b);
		LPanelTop.add(label6a);
		LPanelTop.add(label6b);
		
		LPanelCenter.setLayout(new BoxLayout(LPanelCenter, BoxLayout.Y_AXIS));
		JLabel label7 = new JLabel("Board Color");
		label7.setPreferredSize(new Dimension(20,20));
		label7.setFont(font1);
		String[] options = {"White","Green","Orange"};
		JComboBox<String> colorSelection = new JComboBox<String>(options);
		colorSelection.setPreferredSize(new Dimension(20,20));
		String color = (String) colorSelection.getSelectedItem();
		
		if(color.equals("White")) {
			sudokuPanel.changeColor(WHITE);
		}
		else if(color.equals("Green")) {
			sudokuPanel.changeColor(GREEN);
		}
		else if(color.equals("Orange")) {
			sudokuPanel.changeColor(ORANGE);
		}
		
		
		
		LPanelCenter.add(label7);
		LPanelCenter.add(colorSelection);
		
		LPanelBottom.setLayout(new BoxLayout(LPanelBottom, BoxLayout.Y_AXIS));
		JLabel label8 = new JLabel("Timer");
		label8.setPreferredSize(new Dimension(20,20));
		label8.setFont(font1);
		JButton button1 = new JButton("Play Now");
		JLabel label9 = new JLabel("00:" + minutes + ":" + seconds + ":" + mseconds);
		
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
			/////TIMER///////
				long elapsedTime = 0;
			while (elapsedTime < 1800001) {
				long startTime = System.currentTimeMillis();
				elapsedTime = System.currentTimeMillis() - startTime;
				//elapsedTime = elapsedTime/1000 ;
				
				mseconds = Integer.toString((int)(elapsedTime));
				seconds = Integer.toString((int)(elapsedTime % 60));
				minutes = Integer.toString((int)((elapsedTime % 3600) / 60));
				
				if (mseconds.length() < 2)
					mseconds = "0" + mseconds;

				if (seconds.length() < 2)
				seconds = "0" + seconds;

				if (minutes.length() < 2)
				minutes = "0" + minutes;
				
				label9.setText("00:" + minutes + ":" + seconds + ":" + mseconds);
			}
			
				
				
				
				
				
				
				
//				timer = new Timer(30000, new ActionListener() {
//					@Override
//					public void actionPerformed(ActionEvent e) {
//				        while (minute < 31 ) {
//				        if (count < 100000) {
//				        	label9.setText(Integer.toString(hour) + ":" + Integer.toString(minute) + ":" + Integer.toString(second)
//				        	+ ":" + Integer.toString(msecond));
//				        	count++;
//				        	if (msecond < 1000) {
//				        		msecond++;
//				        	}
//				        	else if (msecond >= 1000 && second <60) {
//				        		second++;
//				        	}
//				        	else if (msecond >= 1000 && second >=60) {
//				        		minute++;
//				        	}
//				        	
//				        } 
//				        else {
//				          ((Timer) (e.getSource())).stop();
//				        }
//				      }
//				    }
//				});
//				    timer.setInitialDelay(0);
//				    timer.start();
				///////END TIMER////////
			}
		});
		
		
		
		LPanelBottom.add(label8);
		LPanelBottom.add(label9);
		LPanelBottom.add(button1);
		
		LPanel.setLayout(new BoxLayout(LPanel, BoxLayout.Y_AXIS));
		LPanel.add(label1);
		LPanel.add(LPanelTop);
		LPanel.add(LPanelCenter);
		LPanel.add(LPanelBottom);
		
		
		Font font = new Font("Arial", Font.BOLD,26);
		JLabel label10 = new JLabel("Sudoku", SwingConstants.CENTER);
		label10.setSize(50,20);
		label10.setFont(font);
		
		
		LPanelTop.setPreferredSize(new Dimension(200,340));
		LPanelCenter.setPreferredSize(new Dimension(200,170));
		LPanelBottom.setPreferredSize(new Dimension(200,170));
		LPanel.setPreferredSize(new Dimension(200,680));
	
		sudokuPanel.setPreferredSize(new Dimension(680,680));
		sudokuPanel.setLayout(new GridLayout(9,9));
		
		RPanel.setLayout(new BoxLayout(RPanel, BoxLayout.Y_AXIS));
		RPanel.add(label10);
		RPanel.add(sudokuPanel);
		
		GridLayout layout2 = new GridLayout(0,2);
		frame.setLayout(layout2);
		frame.add(LPanel);
		frame.add(RPanel);
		//homePanel.setLayout(new BoxLayout(homePanel,BoxLayout.X_AXIS));
		
		//homePanel.add(LPanel);
		//homePanel.add(RPanel);
		
		
		//frame.add(homePanel);
		
	
		
		// Provide final details regarding JFrame.
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(1000,700);
	    frame.setLocation(325,600);
	    frame.setResizable(true);
	    frame.setVisible(true);
	}
	
	
}

		